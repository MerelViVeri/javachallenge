package exercise3;

public class Calculator {

    int result;

    public void performCalculation(int firstNumber, String operator, int secondNumber) {
        // TODO calculate the requested operation and set the result in the result variable
    }

    // TODO create a method that returns the variable result.
    // getResult()
}
